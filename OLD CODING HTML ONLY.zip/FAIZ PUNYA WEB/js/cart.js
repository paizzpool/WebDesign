// Cart functionality
function updateCartCount() {
 const cartItems = JSON.parse(localStorage.getItem("cartItems")) || [];
 const cartCount = document.querySelector(".cart-count");
 if (cartItems.length > 0) {
  cartCount.style.display = "block";
  cartCount.textContent = cartItems.reduce(
   (total, item) => total + item.quantity,
   0
  );
 } else {
  cartCount.style.display = "none";
 }
}

function updateSize(select) {
 const button = select.parentElement.querySelector(".add-to-cart-btn");
 button.setAttribute("data-size", select.value);
}

function addToCart(button) {
 const size = button.getAttribute("data-size");
 if (!size) {
  alert("Please select a size first");
  return;
 }

 const item = {
  id: button.getAttribute("data-id"),
  name: button.getAttribute("data-name"),
  price: parseFloat(button.getAttribute("data-price")),
  img: button.getAttribute("data-img"),
  size: size,
  quantity: 1,
 };

 let cartItems = JSON.parse(localStorage.getItem("cartItems")) || [];

 const existingItemIndex = cartItems.findIndex(
  (cartItem) => cartItem.id === item.id && cartItem.size === item.size
 );

 if (existingItemIndex > -1) {
  cartItems[existingItemIndex].quantity += 1;
 } else {
  cartItems.push(item);
 }

 localStorage.setItem("cartItems", JSON.stringify(cartItems));
 updateCartCount();
 alert("Item added to cart!");
}

function removeFromCart(id, size) {
 let cartItems = JSON.parse(localStorage.getItem("cartItems")) || [];
 cartItems = cartItems.filter(
  (item) => !(item.id === id && item.size === size)
 );
 localStorage.setItem("cartItems", JSON.stringify(cartItems));
 displayCartItems();
 updateCartCount();
}

function updateQuantity(id, size, newQuantity) {
 let cartItems = JSON.parse(localStorage.getItem("cartItems")) || [];
 const itemIndex = cartItems.findIndex(
  (item) => item.id === id && item.size === size
 );

 if (itemIndex > -1) {
  if (newQuantity < 1) {
   removeFromCart(id, size);
   return;
  }
  cartItems[itemIndex].quantity = parseInt(newQuantity);
  localStorage.setItem("cartItems", JSON.stringify(cartItems));
  displayCartItems();
 }
}

function calculateTotals() {
 const cartItems = JSON.parse(localStorage.getItem("cartItems")) || [];
 const subtotal = cartItems.reduce(
  (total, item) => total + item.price * item.quantity,
  0
 );
 const shipping = subtotal > 0 ? 10 : 0; // Example shipping cost
 const total = subtotal + shipping;

 document.getElementById("subtotal-amount").textContent = subtotal.toFixed(2);
 document.getElementById("shipping-amount").textContent = shipping.toFixed(2);
 document.getElementById("total-amount").textContent = total.toFixed(2);
}

function displayCartItems() {
 const cartItemsContainer = document.querySelector(".cart-items");
 if (!cartItemsContainer) return;

 const cartItems = JSON.parse(localStorage.getItem("cartItems")) || [];

 if (cartItems.length === 0) {
  cartItemsContainer.innerHTML = `
			<div class="empty-cart" data-aos="fade-up">
				<i class="fa-solid fa-cart-shopping"></i>
				<h2>Your cart is empty</h2>
				<p>Looks like you haven't added anything to your cart yet</p>
				<a href="index.html" class="btn">Start Shopping</a>
			</div>
		`;
 } else {
  cartItemsContainer.innerHTML = cartItems
   .map(
    (item) => `
			<div class="cart-item" data-aos="fade-up">
				<div class="item-image">
					<img src="${item.img}" alt="${item.name}">
				</div>
				<div class="item-details">
					<div class="item-header">
						<h3 class="item-name">${item.name}</h3>
						<button class="remove-btn" onclick="removeFromCart('${item.id}', '${
     item.size
    }')">
							<i class="fa-solid fa-trash"></i>
						</button>
					</div>
					<p class="item-size">Size: ${item.size}</p>
					<p class="item-price">$${item.price}</p>
					<div class="quantity-control">
						<button onclick="updateQuantity('${item.id}', '${item.size}', ${
     item.quantity - 1
    })">-</button>
						<input type="number" value="${item.quantity}" min="1" 
							onchange="updateQuantity('${item.id}', '${item.size}', this.value)">
						<button onclick="updateQuantity('${item.id}', '${item.size}', ${
     item.quantity + 1
    })">+</button>
					</div>
					<p class="item-total">Total: $${(item.price * item.quantity).toFixed(2)}</p>
				</div>
			</div>
		`
   )
   .join("");
 }

 calculateTotals();
}

function checkout() {
 const cartItems = JSON.parse(localStorage.getItem("cartItems")) || [];
 if (cartItems.length === 0) {
  alert("Your cart is empty!");
  return;
 }

 alert("Thank you for your purchase!");
 localStorage.removeItem("cartItems");
 displayCartItems();
 updateCartCount();
}

// Initialize cart display
document.addEventListener("DOMContentLoaded", () => {
 updateCartCount();
 displayCartItems();
});

// Add burger menu functionality
document.querySelector(".burger_icon").addEventListener("click", function () {
 document.querySelector("nav ul").classList.toggle("active");
});
