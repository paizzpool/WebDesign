const col_btn = document.querySelectorAll(".btn-col");
const col_item = document.querySelectorAll(".collection-item");

col_btn.forEach((btn, index) => {
 btn.addEventListener("click", (e) => {
  col_btn.forEach((col_bt, ind) => {
   col_bt.classList.remove("btn");
  });
  e.target.classList.add("btn");
  let data_btn = btn.getAttribute("data-btn");
  col_item.forEach((col, inde) => {
   if (col.getAttribute("data-item") == data_btn || data_btn == "all") {
    col.classList.remove("hide");
   } else {
    col.classList.add("hide");
   }
  });
 });
});

// Navigation
const ul = document.querySelector("ul");
const burgerIcon = document.querySelector(".burger_icon");

if (!ul || !burgerIcon) {
 console.error("Navigation elements not found");
} else {
 burgerIcon.addEventListener("click", () => {
  const isMenuClosed = burgerIcon.classList.contains("fa-bars");
  burgerIcon.classList.toggle("fa-xmark", isMenuClosed);
  burgerIcon.classList.toggle("fa-bars", !isMenuClosed);
  ul.classList.toggle("active", isMenuClosed);
 });
}

// Shopping cart initialization
let shoppingCart;

document.addEventListener("DOMContentLoaded", () => {
 shoppingCart = new ShoppingCart();
 updateCartCount();

 // Size selection handling
 const sizeSelects = document.querySelectorAll(".size-select");
 sizeSelects.forEach((select) => {
  select.addEventListener("change", function () {
   const button =
    this.closest(".col-footer")?.querySelector(".add-to-cart-btn");
   if (button) {
    button.dataset.size = this.value;
   }
  });
 });
});

// Function to add item to cart
function addToCart(button) {
 // Get size from the closest size select element
 const sizeSelect = button
  .closest(".product-actions")
  .querySelector(".size-select");
 const size = sizeSelect.value;

 // Validate size selection
 if (!size) {
  alert("Please select a size first");
  return;
 }

 // Get product details from data attributes
 const product = {
  id: button.getAttribute("data-id"),
  name: button.getAttribute("data-name"),
  price: parseFloat(button.getAttribute("data-price")),
  img: button.getAttribute("data-img"),
  size: size,
  quantity: 1,
 };

 try {
  // Get existing cart from localStorage or initialize empty array
  let cart = JSON.parse(localStorage.getItem("cart")) || [];

  // Check if product already exists in cart with same size
  const existingItemIndex = cart.findIndex(
   (item) => item.id === product.id && item.size === product.size
  );

  if (existingItemIndex !== -1) {
   // Update quantity if item exists
   cart[existingItemIndex].quantity += 1;
  } else {
   // Add new item if it doesn't exist
   cart.push(product);
  }

  // Save updated cart to localStorage
  localStorage.setItem("cart", JSON.stringify(cart));

  // Update cart count in header
  updateCartCount();

  // Show success message
  alert("Product added to cart!");
 } catch (error) {
  console.error("Error saving to cart:", error);
  alert("There was an error adding the item to cart");
 }
}

// Function to update cart count in header
function updateCartCount() {
 const cart = JSON.parse(localStorage.getItem("cart")) || [];
 const totalItems = cart.reduce((sum, item) => sum + item.quantity, 0);

 // Update the cart count display
 const cartCountElement = document.querySelector(".cart-count");
 if (cartCountElement) {
  cartCountElement.textContent = totalItems;
  cartCountElement.style.display = totalItems > 0 ? "inline-block" : "none";
 }
}
